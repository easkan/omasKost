<?php
        include 'header.php';
?>
<body>
    <!-- <script>
        alert("Deze pagina is gemaakt door: Evrim Askan");
    </script> -->
    <main>
        <section class="png">
            <img src="images/1.png" alt="">
            </section>
            <section class="text">
            <p>Neem uw gezin en familie mee, kom met vrienden of vier een overwinning met uw personeel – alles is mogelijk bij Wereld Genieten! Dé plek waar lekker eten, goede drankjes en ultieme gezelligheid samenkomen. Of u nu op ons sfeervolle terras langs het water wilt genieten van een heerlijk drankje of in onze ruime, huiselijke woonkamer wilt aanschuiven voor een smaakvolle maaltijd, bij ons voelt iedereen zich thuis. Ervaar de warme ambiance, proef de verrassende gerechten en laat u verwennen door onze gastvrije service. Wereld Genieten maakt van elke gelegenheid een bijzondere beleving!</p>
            </section>
            <section class="btn">
                <a href="reserveren.php">Reserveer Nu</a>
            </section>
            </main>
    <section class="wrapper"></section>
</body>
<?php
        include 'footer.php';
?>
