<link rel="stylesheet" href="css/style.css">
<script src="js/script.js" defer></script>
    
<header>
    <img class="omaskost" src="images/logo_omas_kost_rotterdam.png" alt=" logo">
    <nav>
    <a href="homepagina.php">Home</a>
    <a href="lunch&diner.php">Lunch & diner</a>
    <a href="locatie.php">Locatie</a>
    <a href="reserveren.php">Reserveren</a>
    <a href="vacatures.php">Vacatures</a>
</nav>
    <button class="menu-icon" onclick="toggleMenu()">☰</button>
</header>
