<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<footer>
    <img src="images/logo_oma.png" alt="logo">
    <article class="info">
        <p>Volg Ons:
            <i class="fa-brands fa-facebook"></i>
            <i class="fa-brands fa-instagram"></i>
        </p>
        <p>Contact us: info@omaskost.nl</p>
        <p>Telefoonnummer: 088-2344556</p>
    </article>
</footer>
